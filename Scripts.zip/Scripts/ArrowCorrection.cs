﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowCorrection : MonoBehaviour
{
    Rigidbody rb;
    public bool aoe;
    public bool regAttack;
    public float radius;
    public float force = 700;
    public int damage = 10;

    private bool collided;


    void Start()
    {
        Destroy(gameObject, 3);
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        transform.rotation = Quaternion.LookRotation(rb.velocity);
    }
    void OnCollisionEnter(Collision co)
    {
        if (!collided)
        {
            collided = true;

            if (aoe)
            {
                Collider[] colliders = Physics.OverlapSphere(transform.position, radius);

                foreach (Collider nearbyObject in colliders)
                {
                    Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
                    if (rb != null)
                    {

                        rb.AddExplosionForce(force, transform.position, radius);
                    }

                    PlayerHealth target = nearbyObject.GetComponent<PlayerHealth>();
                    if (target != null)
                    {
                        target.TakeDamage(damage);
                    }
                }
            }
            if (regAttack)
            {
                PlayerHealth target = co.gameObject.GetComponent<PlayerHealth>();
                if (target != null)
                {
                    target.TakeDamage(damage);
                }
            }
            Destroy(gameObject);
        }
    }
}
