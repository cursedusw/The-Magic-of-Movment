﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class ai_onslought : MonoBehaviour
{

    public float lookRadius = 10f;

    Transform target;
    NavMeshAgent agent;
    public bool fallow;
    public float seeTime = 2;
    public float speed;

    // Start is called before the first frame update
    void Start()
    {
        target = PlayerManager.instance.player.transform;
        agent = GetComponent<NavMeshAgent>();
        fallow = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (fallow)
        {
            Persue();
            FaceTarget();
        }
    }

    void Persue()
    {
        // makes the ai go to the player
        agent.SetDestination(target.position);
    }

    void FaceTarget()
    {
        Vector3 lookDirection = target.transform.position;
        lookDirection.y = this.transform.position.y;
        transform.LookAt(lookDirection);
        //makes the ai look at the player
        //transform.LookAt(target);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, lookRadius);
    }
}

