﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellEffectOne : MonoBehaviour
{
    public GameObject impactVFX;
    public bool aoe;
    public bool regAttack;
    public float radius;
    public float force = 700;
    public float damage = 10;

    private bool collided;


    void Start()
    {
        Destroy(gameObject, 3);
    }
    void OnCollisionEnter(Collision co)
    {
        if (!collided)
        {
            collided = true;

            if (aoe)
            {
                Collider[] colliders = Physics.OverlapSphere(transform.position, radius);

                foreach (Collider nearbyObject in colliders)
                {
                    Rigidbody rb = nearbyObject.GetComponent<Rigidbody>();
                    if (rb != null)
                    {

                        rb.AddExplosionForce(force, transform.position, radius);
                    }

                    Target target = nearbyObject.GetComponent<Target>();
                    if (target != null)
                    {
                        target.TakeDamage(damage);
                    }
                }
            }
            if (regAttack)
            {
                Target target = co.gameObject.GetComponent<Target>();
                if (target != null)
                {
                    target.TakeDamage(damage);
                }
            }


            var impact = Instantiate(impactVFX, co.contacts[0].point, Quaternion.identity) as GameObject;

            Destroy(impact, 2);

            Destroy(gameObject);
        }
    }
}
