﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Bow : MonoBehaviour
{
    public float lookRadius = 10f;

    Transform target;
    public GameObject NPCCam;
    public GameObject projectileOne; 
    public Transform FirePoint;
    public float projectileSpeedOne = 80;
    public float arcRange = 1;
    private float nextTimeToFire = 0f;
    public float fireRate;
    public float range;
    private Vector3 destination;

    // Start is called before the first frame update
    void Start()
    {
        target = PlayerManager.instance.player.transform;
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit see; // raycast for sight of the ai

        Vector3 direction = NPCCam.transform.forward;         


        if (Physics.Raycast(NPCCam.transform.position, direction, out see, range))
        {
            Debug.Log(see.transform.name);

            PlayerHealth player = see.transform.GetComponent<PlayerHealth>();
            if (player != null) //checks for the player
            {
                Debug.Log("player seen");
                if (Time.time >= nextTimeToFire)
                {
                    nextTimeToFire = Time.time + 1f / fireRate;
                    Shoot(); // fires the guns
                }
            }

        }
    }

    void Shoot()
    {
        Ray ray = new Ray(NPCCam.transform.position, NPCCam.transform.forward);
        RaycastHit hit;
        Vector3 direction = NPCCam.transform.forward;

        if (Physics.Raycast(NPCCam.transform.position, direction, out hit, range))
        {
            destination = hit.point;
        }
        else
        {
            destination = ray.GetPoint(1000);
        }

        InstantiateProjectileOne(FirePoint);
    }

    void InstantiateProjectileOne(Transform firePoint)
    {
        var projectileObj = Instantiate(projectileOne, firePoint.position, Quaternion.identity) as GameObject;
        projectileObj.GetComponent<Rigidbody>().velocity = (destination - firePoint.position).normalized * projectileSpeedOne;
    }

}
