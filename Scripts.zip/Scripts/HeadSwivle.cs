﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeadSwivle : MonoBehaviour
{
    Transform target;
    // Start is called before the first frame update
    void Start()
    {
        target = PlayerManager.instance.player.transform;

    }

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(target);
    }
}
